from colorama import init
init()
from colorama import Fore , Back , Style # Fore- font color | Back- Background

print(Fore.GREEN,"hello qxresearcher")

print(Back.RED,"hello qxresearcher")

#to get back to boring B&W: print(Styoe.RESET_ALL)

```
All Variaton on Colors: 

Fore: BLACK RED GREEN YELLOW BLUE MAGENTA CYAN WHITE RESET
Back: BLACK RED GREEN YELLOW BLUE MAGENTA CYAN WHITE RESET
Style: DIM NORMAL BRIGHT RESET_ALL
  
```
